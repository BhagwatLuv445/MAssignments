package com.gmailEmail.Utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.model.Log;

public class DriverUtil {
	
	protected Properties prop;
	protected WebDriver driver;
	protected String browserPath = System.getProperty("user.dir")+"\\lib"+"\\chromedriver.exe";
	protected String browserDriver = "webdriver.chrome.driver";
	protected String configPropertiesPath = System.getProperty("user.dir")+"\\Properties"+"\\config.properties";
	protected String log4jPropertiesPath = System.getProperty("user.dir")+"\\Properties"+"\\log4j.properties";
	protected String screenShotFoldrPath = System.getProperty("user.dir")+"\\ScreenShot"+"\\scrnShot.png";
	protected String BaseUrl;
	protected static Logger log = Logger.getLogger(Log.class.getName());
	//String Node = "http://localhost:4444/wd/hub";
	static{
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
		System.setProperty("testName.current.date.time", /* testName + " " + */ dateFormat.format(new Date()));
	}
	public DriverUtil() throws FileNotFoundException, MalformedURLException{
		
		try {
			prop = new Properties();
			FileInputStream ip = new FileInputStream(configPropertiesPath);
			prop.load(ip);
		} catch (IOException e) {
			e.printStackTrace();
		}
		PropertyConfigurator.configure(log4jPropertiesPath);
		BaseUrl =prop.getProperty("url");
		log.info("Fecthing the Application url from property file");
		String browserName = prop.getProperty("browser");
		log.info("Fetching the browser name from property file");
		if(browserName.equals("chrome")){
			System.setProperty(browserDriver, browserPath);	
			
			//DesiredCapabilities cap = DesiredCapabilities.chrome();
			//driver = new RemoteWebDriver(new URL(Node), cap);
			driver = new ChromeDriver();
			log.info("Open chrome Browser");
		}else if(browserName.equals("firefox")){
			
		}else if(browserName.equals("IE")){
			
		}
		
		driver.manage().window().maximize();
		log.info("Maximizing the browser window");
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		log.info("waiting for pageloading");
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);		
	}
}
