package com.gmailEmail.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class GmailComposeLocators {

	@FindBy(how=How.XPATH,using="//textarea[@name='to']")
	protected WebElement reciepentField;
	
	@FindBy(how=How.XPATH,using="//*[@id=':nt']")
	protected WebElement attachmentLink;
	
	@FindBy(how=How.XPATH,using="//div[text()='Send']")
	protected WebElement sendBtn;
	
	
}
