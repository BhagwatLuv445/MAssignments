package com.gmailEmail.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class GmailLoginLocators {

	@FindBy(how = How.XPATH, using="//*[@id='identifierLink']//div[2]")
	protected WebElement anotherAccountLink;
	
	@FindBy(how = How.XPATH, using="//input[@type='email']")
	protected WebElement emailField;
	
	@FindBy(how = How.XPATH, using="//div[@id='identifierNext']")
	protected WebElement emailNextBtn;
	
	@FindBy(how = How.XPATH, using="//input[@type='password']")
	protected WebElement passwordField;
	
	@FindBy(how = How.XPATH, using="//div[@id=passwordNext]")
	protected WebElement pwdNextBtn;
	
	@FindBy(how = How.XPATH, using="//a[@class='WaidBe']")
	protected WebElement emailIcon;
	
	
}
