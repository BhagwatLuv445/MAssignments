/**
 * 
 */
package com.gmailEmail.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * @author M1043004
 *
 */
public class GmailHomeLocators {

	@FindBy(how=How.XPATH,using="//div[text()='COMPOSE']")
	protected WebElement composeBtn;
	
	@FindBy(how=How.XPATH,using="//a[contains(text(),'Inbox')]")
	protected WebElement inboxLinkBtn;
	
}
