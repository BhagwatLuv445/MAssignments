package com.gmailEmail.Interface;

public interface GmailComposeInterFace {
	
	void setReciepent(String to);
	void setAttachement(String image);
	void clkSendBtn();
}
