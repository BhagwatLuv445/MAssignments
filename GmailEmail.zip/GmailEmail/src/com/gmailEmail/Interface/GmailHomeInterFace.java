package com.gmailEmail.Interface;

import com.gmailEmail.PageAction.GmailCompose;

public interface GmailHomeInterFace {

	GmailCompose clkComposeBtn();
	void clkInboxLink();
}
