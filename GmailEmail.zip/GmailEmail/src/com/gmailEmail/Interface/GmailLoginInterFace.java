package com.gmailEmail.Interface;

import java.io.IOException;

import com.gmailEmail.PageAction.GmailHome;

public interface GmailLoginInterFace {
	
	void chooseAccountLinkBtn();
	void enterEmail(String email);
	void clkEmaiNextBtn();
	void enterPasswordField(String password) throws InterruptedException;
	GmailHome clkPasswordNextBtn() throws IOException;
}
