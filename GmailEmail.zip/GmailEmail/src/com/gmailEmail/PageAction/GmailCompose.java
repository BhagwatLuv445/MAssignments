package com.gmailEmail.PageAction;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.openqa.selenium.support.ui.Wait;

import com.gmailEmail.Interface.GmailComposeInterFace;
import com.gmailEmail.Locators.GmailComposeLocators;
import com.google.common.base.Function;

public class GmailCompose extends GmailComposeLocators implements GmailComposeInterFace {

	// @FindBy(how = How.XPATH, using = "//textarea[@role='combobox']")
	// protected WebElement recipientField;

	@FindBy(how = How.XPATH, using = "//*[@command='Files']")
	protected WebElement attachmentLink;

	@FindBy(how = How.XPATH, using = "//div[text()='Send']")
	protected WebElement sendBtn;

	WebDriver driver;
	WebDriverWait wait;
	Logger log;

	public GmailCompose(WebDriver driver, Logger log) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 10000);
	}

	public void setReciepent(String to) {

		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);
		WebElement recipientField = wait.until(new Function<WebDriver, WebElement>() 
		{
			public WebElement apply(WebDriver driver) 
			{		
				WebElement e = driver.findElement(By.xpath("//*[@id=':mj']"));
				e.sendKeys(to);
				e.sendKeys(Keys.ENTER);

				log.info("Recipiens input field found");
				log.info("Recipients email address entered");
				return e;
			}
		});
	}

	public void setAttachement(String image) {
		System.out.println(image);
		WebElement attachmentLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@command='Files']")));
		log.info("Attachment Link found");
		attachmentLink.sendKeys(image);
		log.info("ScreenShot Attached");
	}

	public void clkSendBtn() {
		WebElement sendBtn = driver.findElement(By.xpath("//div[text()='Send']"));
		log.info("Send Button Found");
		sendBtn.click();
		log.info("Click on Send Button");
		driver.switchTo().alert().accept();
		log.info("Handle the alert pop up");
	}

}
