package com.gmailEmail.PageAction;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gmailEmail.Interface.GmailHomeInterFace;
import com.gmailEmail.Locators.GmailHomeLocators;

public class GmailHome extends GmailHomeLocators implements GmailHomeInterFace {

	WebDriver driver;
	WebDriverWait wait;
	Logger log;

	public GmailHome(WebDriver driver, Logger log) {
		this.log = log;
		this.driver = driver;
		wait = new WebDriverWait(driver, 5000);
	}

	public GmailCompose clkComposeBtn() {
		WebElement composeBtn = driver.findElement(By.xpath("//div[text()='COMPOSE']"));
		log.info("Compose button is found to click and compose the email");		
		composeBtn.click();
		driver.manage().timeouts().pageLoadTimeout(50,TimeUnit.SECONDS);
		log.info("Click on Compose Button to compose an Email");
		return new GmailCompose(driver, log);
	}

	public void clkInboxLink() {
		WebElement inboxLinkBtn = driver.findElement(By.xpath("//a[contains(text(),'Inbox')]"));
		log.info("Inbox button is found to click and check the incoming emails");
		inboxLinkBtn.click();
		log.info("Click is performed on Inbox button");
	}

}
