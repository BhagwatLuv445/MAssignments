package com.gmailEmail.PageAction;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gmailEmail.Interface.GmailLoginInterFace;
import com.gmailEmail.Locators.GmailLoginLocators;
import com.gmailEmail.Utility.ScreenShot;

public class GmailLogin extends GmailLoginLocators implements GmailLoginInterFace {

	WebDriver driver;
	WebDriverWait wait;
	Logger log;

	public GmailLogin(WebDriver driver, Logger log) {
		this.driver = driver;
		this.log = log;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 5000);
		log.info("WebDriverWait Initialize by 5000 miliSeconds");
	}

	public void chooseAccountLinkBtn() {
		System.out.println("another btn");
		anotherAccountLink.click();
		log.info("Element found to login into another account");
		log.info("Click on another account login element to login");
	}

	public void enterEmail(String email) {
		System.out.println("email field");
		WebElement emailField = driver.findElement(By.xpath("//input[@type='email']"));
		log.info("Email address input field found to enter email address");		
		wait.until(ExpectedConditions.visibilityOf(emailField));		
		emailField.sendKeys(email);
		log.info("Email entered in Email text field");
	}

	public void clkEmaiNextBtn() {
		System.out.println("email btn");
		WebElement emailNextBtn = driver.findElement(By.xpath("//div[@id='identifierNext']"));
		log.info("Next button is found to navigate for entering password");			
		emailNextBtn.click();
		log.info("Click on Next Button to navigate for entering password");
	}

	public void enterPasswordField(String password) throws InterruptedException {
		System.out.println("pwd field");
		WebElement passwordField = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type='password']")));
		log.info("Explicit wait is given for password field for 5000 milisecods");
		log.info("Password input field is found for entering password");
		passwordField.sendKeys(password);
		log.info("Password entered in password input field");
	}

	public GmailHome clkPasswordNextBtn() throws IOException {
		System.out.println("pwd btn");
		WebElement pwdNextBtn = driver.findElement(By.xpath("//div[@id='passwordNext']"));
		log.info("Next Button found to navigate to next page");
		pwdNextBtn.click();
		log.info("Click on Next Button");
		// assert(driver.getTitle().equals("My Account"));
		WebElement emailIcon = driver.findElement(By.xpath("//a[@class='WaidBe']"));
		log.info("Gmail Icon Found to navigate to homepage");
		emailIcon.click();
		log.info("Click on Gmail Icon to get inside the Home Page");
		ScreenShot.takeSnapShot(driver);
		log.info("Taking SnapShot of Home Page");
		return new GmailHome(driver, log);
	}

}
