package com.gmailEmail.testCases;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.gmailEmail.Interface.GmailComposeInterFace;
import com.gmailEmail.Interface.GmailHomeInterFace;
import com.gmailEmail.Interface.GmailLoginInterFace;
import com.gmailEmail.PageAction.GmailLogin;
import com.gmailEmail.Utility.DriverUtil;

public class GmailTest extends DriverUtil {

	GmailLoginInterFace gmailLoginInterFace;
	GmailHomeInterFace gmailHomeInterFace;
	GmailComposeInterFace gmailComposeInterFace;

	public GmailTest() throws FileNotFoundException, MalformedURLException {
		super();
	}

	@BeforeMethod
	public void init() {
		driver.get(BaseUrl);		
		log.info("Application Launched");
		gmailLoginInterFace = new GmailLogin(driver, log);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Parameters({ "email", "password" })
	@Test
	public void gmailTest(String email, String password) throws InterruptedException, IOException {
		// gmailLoginInterFace.chooseAccountLinkBtn();
		gmailLoginInterFace.enterEmail(email);
		gmailLoginInterFace.clkEmaiNextBtn();
		gmailLoginInterFace.enterPasswordField(password);
		gmailHomeInterFace = gmailLoginInterFace.clkPasswordNextBtn();
		gmailComposeInterFace = gmailHomeInterFace.clkComposeBtn();
		
		//System.out.println(screenShotFoldrPath);
		
		gmailComposeInterFace.setReciepent("bhagwat9094@gmail.com");
		System.out.println("email insert");
		gmailComposeInterFace.setAttachement(screenShotFoldrPath);
		gmailComposeInterFace.clkSendBtn();
	}

}
