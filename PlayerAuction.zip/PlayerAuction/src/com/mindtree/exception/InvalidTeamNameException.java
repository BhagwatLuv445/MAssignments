package com.mindtree.exception;

public class InvalidTeamNameException extends Exception {

	public InvalidTeamNameException(String string) {
		System.out.println(string);
	}

}
