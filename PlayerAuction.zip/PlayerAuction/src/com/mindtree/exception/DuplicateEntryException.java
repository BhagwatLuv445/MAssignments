package com.mindtree.exception;

public class DuplicateEntryException extends Exception {

	public DuplicateEntryException() {
		// TODO Auto-generated constructor stub
	}

	public DuplicateEntryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DuplicateEntryException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public DuplicateEntryException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DuplicateEntryException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
