package com.mindtree.exception;

public class NotABatsmanException extends Exception {

	public NotABatsmanException(String string) {
		System.out.println(string);
	}

}
