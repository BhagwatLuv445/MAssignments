package com.mindtree.exceptions;

import java.sql.SQLException;

public class DaoException extends Exception {

	public DaoException(SQLException e) {
		// TODO Auto-generated constructor stub
	}

	public DaoException(String string) {
		// TODO Auto-generated constructor stub
	}

}
