package com.mindtree.exceptions;

public class InvalidCategoryException extends Exception {

	public InvalidCategoryException(String string) {
		System.out.println(string);
	}

}
