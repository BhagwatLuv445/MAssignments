package com.mindtree.dao;

public interface PlayerDao {

}
