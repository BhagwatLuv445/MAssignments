package com.Amazon.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.Amazon.Utility.TestBase;

public class ProductsPageLocators extends TestBase{

	@FindBy(className="s-access-title")
	protected WebElement first_product;
	
}
