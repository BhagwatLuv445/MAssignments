package com.Amazon.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.Amazon.Utility.TestBase;

public class AddToCartConfirmLocators extends TestBase {

	@FindBy(how=How.XPATH,using="//h1[contains(text(),'Added to Cart')]")
	protected WebElement confirmText;
}
