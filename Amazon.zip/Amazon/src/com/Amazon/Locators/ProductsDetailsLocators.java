package com.Amazon.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.Amazon.Utility.TestBase;

public class ProductsDetailsLocators extends TestBase{

	@FindBy(how = How.XPATH, using = "productTitle")
	protected WebElement productTitle;

	@FindBy(how = How.XPATH, using = "//*[@id='addToCart']/div/div[3]")
	protected WebElement addToCartBtn;

	@FindBy(how=How.XPATH,using ="//*[@id='siAddCoverage-announce']")
	protected WebElement addToOrder;
}
