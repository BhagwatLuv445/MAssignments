package com.Amazon.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.Amazon.Utility.TestBase;

public class LoginPageLocators extends TestBase {

	@FindBy(name = "email")
	protected WebElement emailField;

	@FindBy(id = "continue")
	protected WebElement continueBtn;

	@FindBy(how = How.XPATH, using = "//*[@id='a-page']//a/span")
	protected WebElement needHelpLink;

	@FindBy(how = How.XPATH, using = "//*[@id='createAccountSubmit']")
	protected WebElement createAccountBtn;

	@FindBy(name = "password")
	protected WebElement passwordField;

	@FindBy(id = "signInSubmit")
	protected WebElement signInSubmitBtn;

	@FindBy(name = "rememberMe")
	protected WebElement rememberMeChkBox;

	@FindBy(how = How.XPATH, using = "//*[@id='continue']")
	protected WebElement loginOtpBtn;
}
