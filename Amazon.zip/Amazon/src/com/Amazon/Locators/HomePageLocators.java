package com.Amazon.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.Amazon.Utility.TestBase;

public class HomePageLocators extends TestBase {

	/*@FindBy(how = How.ID, using = "nav-link-yourAccount")
	protected WebElement signInHoverBtn;*/
	
	@FindBy(how = How.XPATH, using = "//*[@id='nav-flyout-ya-signin']/a/span")
	protected WebElement signInBtn;
	
	@FindBy(name="field-keywords")
	protected WebElement searchBox;
	
	
	protected String signInHoverBtn="nav-link-yourAccount";
	
}
