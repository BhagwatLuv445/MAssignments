package com.Amazon.Utility;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.TestException;

public abstract class CommonUtil extends TestBase{

	 public static WebDriver _driver;
	    public WebDriverWait wait;
	    public Actions actions;
	    public Select select;
	    public CommonUtil(){
	    	super();
	    }
	 public void navigateToURL(String URL) {
	        try {
	            _driver.get(URL);
	        } catch (Exception e) {
	            System.out.println("FAILURE: URL did not load: " + URL);
	            throw new TestException("URL did not load");
	        }
	    }

	    public void navigateBack() {
	        try {
	            _driver.navigate().back();
	        } catch (Exception e) {
	            System.out.println("FAILURE: Could not navigate back to previous page.");
	            throw new TestException("Could not navigate back to previous page.");
	        }
	    }

	    public String getPageTitle() {
	        try {
	            return _driver.getTitle();
	        } catch (Exception e) {
	            throw new TestException(String.format("Current page title is: %s", _driver.getTitle()));
	        }
	    }

	    public String getCurrentURL() {
	        try {
	            return _driver.getCurrentUrl();
	        } catch (Exception e) {
	            throw new TestException(String.format("Current URL is: %s", _driver.getCurrentUrl()));
	        }
	    }
}
