package com.Amazon.PageObject;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.Amazon.Interfaces.IHomePage;
import com.Amazon.Locators.HomePageLocators;

public class HomePage extends HomePageLocators implements IHomePage {

//	WebDriver driver;
	Actions action;
	//String mainWindow = driver.getWindowHandle();
	public HomePage() {
		//this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// WebDriverWait wait = new
	public WebElement getEle(String id) {
		WebElement signInHoverBtn = driver.findElement(By.id(id));
		return signInHoverBtn;
	}

	public LoginPage signInHoverBtn() throws InterruptedException {

		// Thread.sleep(2000);
		action = new Actions(driver);
		// WebElement signInHoverBtn =
		// driver.findElement(By.id("nav-link-yourAccount"));

		action.moveToElement(getEle(signInHoverBtn)).build().perform();
		WebElement signInBtn = driver.findElement(By.xpath("//*[@id='nav-flyout-ya-signin']/a/span"));
		action.moveToElement(signInBtn).click().perform();
		return new LoginPage();
	}

	public void clksignInBtn(Logger log) {

		try {
			if (signInBtn.isDisplayed()) {
				signInBtn.click();
			} else {
				throw new Exception();
			}
		} catch (Exception e) {
			log.error("Sign In Button is Not Displaying");
		}
	}

	public ProductsPage searchItem(String Item) {

		WebElement searchBox = driver.findElement(By.name("field-keywords"));
		action = new Actions(driver);
		Action seriesOfActions = action.moveToElement(searchBox).click().keyDown(searchBox, Keys.SHIFT).sendKeys(Item)
				.keyUp(searchBox, Keys.SHIFT).sendKeys(Keys.ENTER).build();
		seriesOfActions.perform();

		System.out.println("hi" + "driver: " + driver);
		ProductsPage page = new ProductsPage();
		// page.setDriver(driver);
		return page;
	}

}
