package com.Amazon.PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.Amazon.Interfaces.ILoginPage;
import com.Amazon.Locators.LoginPageLocators;

public class LoginPage extends LoginPageLocators implements ILoginPage {

	//WebDriver driver;

	public LoginPage() {
		//this.driver = driver;
		PageFactory.initElements(driver, LoginPageLocators.class);
	}

	public void enterEmail(String email) {
		WebElement emailField = driver.findElement(By.name("email"));
		emailField.sendKeys(email);
	}

	public void enterPassword(String password) {
		WebElement passwordField = driver.findElement(By.name("password"));
		passwordField.sendKeys(password);
	}

	public void clkContinueBtn() {
		 WebElement continueBtn = driver.findElement(By.id("continue"));
		continueBtn.click();
	}

	public void clkLoginBtn() {
		 WebElement signInSubmitBtn =
		 driver.findElement(By.id("signInSubmit"));
		signInSubmitBtn.click();
	}

	public void clkNeedHelpLinkBtn() {

	}

	public void clkCreateAccountBtn() {

	}

}
