package com.Amazon.PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.Amazon.Interfaces.IProductsPage;
import com.Amazon.Locators.ProductsPageLocators;

public class ProductsPage extends ProductsPageLocators implements IProductsPage {

	// @FindBy(how = How.CLASS_NAME,using="s-access-title")

	// WebDriver driver;
	// WebElement first_product;

	public ProductsPage() {
		System.out.println(driver);
		// this.driver = driver;
		PageFactory.initElements(driver, this);
		// first_product = driver.findElement(By.className("s-access-title"));
	}

	public String getFirstResultTitle() {
		return first_product.getText();
	}

	public ProductsDetailsPage clickFirstResultTitle() {
		first_product.click();
		System.out.println("clikc first result");
		return new ProductsDetailsPage();
	}

	public void first_Item_clk() {
		first_product.click();
	}

	/*
	 * public void setDriver(WebDriver driver){ System.out.println(driver);
	 * this.driver = driver; first_product =
	 * driver.findElement(By.className("s-access-title")); }
	 */

}
