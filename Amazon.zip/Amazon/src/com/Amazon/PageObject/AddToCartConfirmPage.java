package com.Amazon.PageObject;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.Amazon.Interfaces.IAddToCartConfirm;
import com.Amazon.Locators.AddToCartConfirmLocators;

public class AddToCartConfirmPage extends AddToCartConfirmLocators implements IAddToCartConfirm{
	//WebDriver driver;

	public AddToCartConfirmPage() {
		//this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String getConfirmationText() {		
		/*Set<String> s1 = driver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();
		while(i1.hasNext()){
			String childWindow = i1.next();			
		}*/
		return confirmText.getText();		
	}
}
