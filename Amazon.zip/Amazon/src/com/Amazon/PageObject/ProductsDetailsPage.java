package com.Amazon.PageObject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.Amazon.Interfaces.IProductsDetails;
import com.Amazon.Locators.ProductsDetailsLocators;

public class ProductsDetailsPage extends ProductsDetailsLocators implements IProductsDetails{

	//WebDriver driver;
	WebDriverWait wait = new WebDriverWait(driver, 5000);
	public ProductsDetailsPage() {
		//this.driver = driver;
		PageFactory.initElements(driver, this);
		System.out.println(driver);
	}

	public String getProductTitle() {
		return productTitle.getText();
	}

	public AddToCartConfirmPage addToCart() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//		WebElement addToCartBtn = driver.findElement(By.xpath("//*[@id='addToCart']/div/div[3]"));
		wait.until(ExpectedConditions.visibilityOf(addToCartBtn));
		addToCartBtn.click();
		//addToOrder.click();
		
		return new AddToCartConfirmPage();
}
}
