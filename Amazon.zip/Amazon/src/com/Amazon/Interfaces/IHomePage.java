package com.Amazon.Interfaces;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.Amazon.PageObject.LoginPage;
import com.Amazon.PageObject.ProductsPage;

public interface IHomePage {

	LoginPage signInHoverBtn() throws InterruptedException;	
	void clksignInBtn(Logger log);
	ProductsPage searchItem(String Item);
}
