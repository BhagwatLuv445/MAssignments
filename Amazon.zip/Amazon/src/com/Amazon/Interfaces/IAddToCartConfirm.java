package com.Amazon.Interfaces;

public interface IAddToCartConfirm {

	String getConfirmationText();
}
