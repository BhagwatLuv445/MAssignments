package com.Amazon.Interfaces;

public interface IProductsPage {

	void first_Item_clk();
}
