package com.Amazon.Interfaces;

public interface ILoginPage {

	void enterEmail(String email);
	void enterPassword(String password);
	void clkContinueBtn();
	void clkLoginBtn();
	void clkNeedHelpLinkBtn();
	void clkCreateAccountBtn();
	
}
