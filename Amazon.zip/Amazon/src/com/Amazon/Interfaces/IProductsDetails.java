package com.Amazon.Interfaces;

import com.Amazon.PageObject.AddToCartConfirmPage;

public interface IProductsDetails {

	 String getProductTitle();
	 AddToCartConfirmPage addToCart();
}
