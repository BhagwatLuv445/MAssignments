package com.mercury.interfaces;

import com.mercury.pages.ConfirmBooking;

public interface IBookingFlight {

	void serPassengerFirstName(String firstName);

	void setPassengerLastName(String lastName);

	void setMeal(String meal);

	void setCardType(String cardTypeName);

	void setCardNumber(String cardNum);

	void setCardExpMonth(String expMonth);

	void setExpYear(String expYear);

	void setCCfirstName(String ccfirstName);

	void setCCMidName(String ccmidName);

	void setccLastName(String cclastName);

	void setBillAddress(String billAdd);

	void setBillCity(String billingCity);

	void setBillState(String billingState);

	void setZip(String zipCode);

	void setBillCountry(String billingCountry);

	void clkPurchaseBtn();
}
