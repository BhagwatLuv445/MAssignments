package com.mercury.interfaces;

public interface IConfirmBooking {

	void clkLogout();
}
