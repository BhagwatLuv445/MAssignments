package com.mercury.interfaces;

import com.mercury.pages.BookFlightPage;

public interface ISelectFlight {

	void selectDepartFlight(String departFlight) ;
	void selectReturnFlight(String returnFlight) ;
	void clkContinueBtn();
}
