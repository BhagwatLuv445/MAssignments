package com.mercury.interfaces;

public interface IHomePage {

	String validateHomePageTitle();
	void logIn(String un, String pwd);
}
