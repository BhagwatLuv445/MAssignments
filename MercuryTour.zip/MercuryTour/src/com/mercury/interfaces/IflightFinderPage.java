package com.mercury.interfaces;

import com.mercury.pages.SelectFlightPage;

public interface IflightFinderPage {

	String validateFlightFinderPageTitle();
	void setTripType(String trip);
	void setPassenger(String passenger);
	void setDepartingFrom(String departFrom);
	void setDepartMonth(String departMonth);
	void setDepartDay(String departDay);
	void setArrivingPort(String arrivingPlace);
	void setArrivingMonth(String arriveMonth);
	void setArrivingDay(String arriveDay);
	void setServiceClass(String servClass);
	void setAirLine(String airline);
	void clkContinue();
	
}
