/*package com.mercury.testCases;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.mercury.base.TestBase;
import com.mercury.pages.FlightFinderPage;
import com.mercury.pages.HomePage;
import com.mercury.pages.SelectFlightPage;

public class SelectFlightPageTest extends TestBase {

	HomePage homePage;
	SelectFlightPage selectFlightPage;
	FlightFinderPage flightFinderPage;
	public SelectFlightPageTest(){
		super();
	}
	
	@BeforeTest
	public void setUp(){
		initialiazation();
		homePage = new HomePage();
		flightFinderPage = homePage.logIn(prop.getProperty("username"), prop.getProperty("password"));
		//selectFlightPage = flightFinderPage.clkContinue();
		selectFlightPage = new SelectFlightPage();
	}
	
	@Test(dependsOnGroups={"flightfinder"},groups = {"slctflight"},priority = 0)
	public void selectDepartFlightTest(){
		selectFlightPage.selectDepartFlight("Unified Airlines 363");
	}
	
	@Test(dependsOnGroups={"flightfinder"},groups = {"slctflight"},priority = 1)
	public void selectReturnFlightTest(){
		selectFlightPage.selectReturnFlight("Pangea Airlines 632");
	}
	
	@Test(dependsOnGroups={"flightfinder"},groups = {"slctflight"},priority = 2)
	public void clkContinueBtnTest(){
		selectFlightPage.clkContinueBtn();
	}
	
	@AfterTest
	public void tearDown(){
		//driver.quit();
	}
	
}
*/