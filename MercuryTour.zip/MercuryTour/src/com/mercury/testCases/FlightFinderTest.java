/*package com.mercury.testCases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.mercury.base.TestBase;
import com.mercury.pages.FlightFinderPage;
import com.mercury.pages.HomePage;
import com.mercury.pages.SelectFlightPage;
import com.relevantcodes.extentreports.LogStatus;

public class FlightFinderTest extends TestBase {

	HomePage homePage;
	FlightFinderPage flightFinderPage;
	SelectFlightPage selectFlightPage;

	public FlightFinderTest() {
		super();
	}
	//BeforeMethod
	@BeforeTest
	public void setUp() {
		initialiazation();
		homePage = new HomePage();
		flightFinderPage = homePage.logIn(prop.getProperty("username"), prop.getProperty("password"));
		//flightFinderPage.FlightFinderPageDriver(driver);
	}

	@Test
	public void FlightFinderTest(){
		//String title = flightFinderPage.validateFlightFinderPageTitle();
		//logger.log(LogStatus.INFO,"FLightFinder Page Title found");
		//Assert.assertEquals(title,"Find a Flight: Mercury Tours:","FlightFinder Page Title Not Match");
		//logger.log(LogStatus.PASS,"Title Verified");
		flightFinderPage.setTripType("oneway");
		flightFinderPage.setPassenger("" + 4);
		flightFinderPage.setDepartingFrom("New York");
		flightFinderPage.setDepartMonth("November");
		flightFinderPage.setDepartDay("" + 19);
		flightFinderPage.setArrivingPort("London");
		flightFinderPage.setArrivingMonth("November");
		flightFinderPage.setArrivingDay("" + 20);
		flightFinderPage.setServiceClass("Business class");
		flightFinderPage.setAirLine("Unified Airlines");
		selectFlightPage = flightFinderPage.clkContinue();
	}
	@Test(groups = {"flightfinder"},priority = 0)
	public void validateFlightFinderPageTitleTest() {
		String title = flightFinderPage.validateFlightFinderPageTitle();
		//logger.log(LogStatus.INFO,"FLightFinder Page Title found");
		Assert.assertEquals(title,"Find a Flight: Mercury Tours:","FlightFinder Page Title Not Match");
		//logger.log(LogStatus.PASS,"Title Verified");
	}
	
	@Test(groups = {"flightfinder"},priority = 1)
	public void setTripTest() {
		
	}

	@Test(groups = {"flightfinder"},priority = 2)
	public void setPassengerTest() {
		
		//logger.log(LogStatus.INFO,"Passenger selected");
	}

	@Test(groups = {"flightfinder"},priority = 3)
	public void setDepartingFromTest() {
		
	}

	@Test(groups = {"flightfinder"},priority = 4)
	public void setDepartMonthTest() {
		
	}

	@Test(groups = {"flightfinder"},priority = 5)
	public void setDepartDay() {
		
	}

	@Test(groups = {"flightfinder"},priority = 6)
	public void setArrivingPortTest() {
		
	}

	@Test(groups = {"flightfinder"},priority = 7)
	public void setArrivingMonthTest() {
		
	}

	@Test(groups = {"flightfinder"},priority = 8)
	public void setArrivingDayTest() {
		
	}

	@Test(groups = {"flightfinder"},priority = 9)
	public void setServiceClass() {
		
	}

	@Test(groups = {"flightfinder"},priority = 10)
	public void setAirLineTest() {
		
	}

	@Test(groups = {"flightfinder"},priority = 11)
	public void clkContinueTest() {
		
	}
	
	//AfterMethod
	@AfterTest
	public void tearDown(){
		driver.quit();
	}
}
*/