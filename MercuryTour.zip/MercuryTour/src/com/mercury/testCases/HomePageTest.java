package com.mercury.testCases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.mercury.base.TestBase;
import com.mercury.util.MercuryDataProvider;

public class HomePageTest extends TestBase {

	@Parameters({ "username", "password" })
	@BeforeTest
	public void loginTest(String username, String password) {
		homePage.logIn(username, password);
		System.out.println(flightFinderPage);
	}

	@Parameters({ "tripType", "passengerCount", "departFrom", "departmonth", "departDay", "arrivePort", "arriveMonth",
			"arriveDay", "serviceClass", "airLine" })
	@Test(priority = 1)
	public void FlightFinderTest(String tripType, String passengerCount, String departForm, String departMonth,
			String departDay, String arrivePort, String arriveMonth, String arriveDay, String serviceClass,
			String airLine) {
		flightFinderPage.setTripType(tripType);
		flightFinderPage.setPassenger(passengerCount);
		flightFinderPage.setDepartingFrom(departForm);
		flightFinderPage.setDepartMonth(departMonth);
		flightFinderPage.setDepartDay(departDay);
		flightFinderPage.setArrivingPort(arrivePort);
		flightFinderPage.setArrivingMonth(arriveMonth);
		flightFinderPage.setArrivingDay(arriveDay);
		flightFinderPage.setServiceClass(serviceClass);
		flightFinderPage.setAirLine(airLine);
		flightFinderPage.clkContinue();
		System.out.println(selectFlightPage);
	}

	@Parameters({ "departFlight", "returnFlight" })
	@Test(priority = 2)
	public void selectFlightTest(String departFlight, String returnFlight) {
		selectFlightPage.selectDepartFlight("Unified Airlines 363 281 11:24");
		selectFlightPage.selectReturnFlight("Pangea Skies Airlines 632 282 16:37");
		selectFlightPage.clkContinueBtn();
	}

	@Test(priority = 3, dataProvider = "mecuryDataProvider", dataProviderClass = MercuryDataProvider.class)
	public void bookingTest(String passengerFirstName, String passengerLastName, String meal, String cardType,
			String cardNumber, String cardExpMonth, String CardExpYear, String cardFirstName, String cardMidName,
			String cardLastName, String billCity, String billState, String Zipcode, String country) {
		bookingFlight.serPassengerFirstName(passengerFirstName);
		bookingFlight.setPassengerLastName(passengerLastName);
		bookingFlight.setMeal(meal);
		bookingFlight.setCardType(cardType);
		bookingFlight.setCardNumber(cardNumber);
		bookingFlight.setCardExpMonth(cardExpMonth);
		bookingFlight.setExpYear(CardExpYear);
		bookingFlight.setCCfirstName(cardFirstName);
		bookingFlight.setCCMidName(cardMidName);
		bookingFlight.setccLastName(cardLastName);
		bookingFlight.setBillCity(billCity);
		bookingFlight.setBillState(billState);
		bookingFlight.setZip(Zipcode);
		bookingFlight.setBillCountry(country);
		bookingFlight.clkPurchaseBtn();
	}

	@Test(priority = 4)
	public void confirmLogout() {
		cnfrmbooking.clkLogout();
	}

}
