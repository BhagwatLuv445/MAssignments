package com.mercury.locators;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.mercury.base.TestBase;

public class FlightFinderLocators extends TestBase{

	// Page Object - OR:
	@FindBy(how = How.XPATH, using = "//input[@name='tripType']")
	protected List<WebElement> tripType;

	@FindBy(how = How.XPATH, using = "//input[@value='roundtrip']")
	protected WebElement roundTrip;

	@FindBy(how = How.XPATH, using = "//input[@value='oneway']")
	protected WebElement onewayTrip;

	@FindBy(how = How.XPATH, using = "//select[@name='passCount']")
	protected WebElement passengerCount;

	@FindBy(how = How.XPATH, using = "//select[@name='fromPort']")
	protected WebElement departingFrom;

	@FindBy(how = How.XPATH, using = "//select[@name='fromMonth']")
	protected WebElement departingMonth;

	@FindBy(how = How.XPATH, using = "//select[@name='fromDay']")
	protected WebElement departingDay;

	@FindBy(how = How.XPATH, using = "//select[@name='toPort']")
	protected WebElement arrivingPort;

	@FindBy(how = How.XPATH, using = "//select[@name='toMonth']")
	protected WebElement arrivingMonth;

	@FindBy(how = How.XPATH, using = "//select[@name='toDay']")
	protected WebElement arrivingDay;

	@FindBy(how = How.XPATH, using = "//input[@name='servClass']")
	protected List<WebElement> serviceClass;

	@FindBy(how = How.XPATH, using = "//select[@name='airline']")
	protected WebElement airLine;

	@FindBy(how = How.XPATH, using = "//td/input")
	protected WebElement continueBtn;
}