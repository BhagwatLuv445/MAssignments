package com.mercury.locators;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.mercury.base.TestBase;

public class SelectFlightLocators extends TestBase {

	// Page Object - OR:
		@FindBy(how = How.NAME, using = "outFlight")
		protected List<WebElement> selectFlight;

		@FindBy(how = How.NAME, using = "inFlight")
		protected List<WebElement> selectReturnFlight;

		@FindBy(how = How.XPATH, using = "//input[@name ='reserveFlights']")
		protected WebElement continueBtn;
}
