package com.mercury.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.mercury.base.TestBase;

public class HomePageLocators extends TestBase
{

	@FindBy(name = "userName")
	protected WebElement userNameField;

	@FindBy(name = "password")
	protected WebElement passWordField;

	@FindBy(name = "login")
	protected WebElement loginBtn;

	@FindBy(how = How.XPATH, using = "'//a[contains(text(),'SIGN-ON')]")
	protected WebElement signOnLink;
}
