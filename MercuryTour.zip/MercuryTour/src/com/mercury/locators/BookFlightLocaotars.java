package com.mercury.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.mercury.base.TestBase;

public class BookFlightLocaotars extends TestBase{

	@FindBy(how=How.NAME,using="passFirst0")
	protected WebElement passsengerFirstName0;
	
	@FindBy(how=How.NAME,using="passFirst1")
	protected WebElement passsengerFirstName1;
	
	@FindBy(how=How.NAME,using="passFirst2")
	protected WebElement passsengerFirstName2;
	
	@FindBy(how=How.NAME,using="passFirst3")
	protected WebElement passsengerFirstName;
	
	@FindBy(how=How.NAME,using="passLast0")
	protected WebElement passsengerLastName0;
	
	@FindBy(how=How.NAME,using="passLast1")
	protected WebElement passsengerLastName1;
	
	@FindBy(how=How.NAME,using="passLast2")
	protected WebElement passsengerLastName2;
	
	@FindBy(how=How.NAME,using="passLast3")
	protected WebElement passsengerLastName3;
	
	@FindBy(how=How.NAME,using="pass.0.meal")
	protected WebElement passengerMeal0;
	
	@FindBy(how=How.NAME,using="pass.1.meal")
	protected WebElement passengerMeal1;
	
	@FindBy(how=How.NAME,using="pass.2.meal")
	protected WebElement passengerMeal2;
	
	@FindBy(how=How.NAME,using="pass.3.meal")
	protected WebElement passengerMeal3;		
	
	@FindBy(how=How.NAME,using="creditCard")
	protected WebElement cardType;
	
	@FindBy(how=How.NAME,using="creditnumber")
	protected WebElement cardNumber;
	
	@FindBy(how=How.NAME,using="cc_exp_dt_mn")
	protected WebElement cardExpMonth;
	
	@FindBy(how=How.NAME,using="cc_exp_dt_yr")
	protected WebElement cardExpYear;
	
	@FindBy(how=How.NAME,using="cc_frst_name")
	protected WebElement ccFirstName;
	
	@FindBy(how=How.NAME,using="cc_mid_name")
	protected WebElement ccMidName;
	
	@FindBy(how=How.NAME,using="cc_last_name")
	protected WebElement ccLastName;
	
	@FindBy(how=How.NAME,using="billAddress1")
	protected WebElement billAddress;
	
	@FindBy(how=How.NAME,using="billCity")
	protected WebElement billCity;
	
	@FindBy(how=How.NAME,using="delState")
	protected WebElement billState;
	
	@FindBy(how=How.NAME,using="delZip")
	protected WebElement billZipCode;
	  
	@FindBy(how=How.NAME,using="delCountry")
	protected WebElement billCountry;
	
	@FindBy(how=How.NAME,using="buyFlights")
	protected WebElement purchaseBtn;
}
