package com.mercury.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.mercury.base.TestBase;

public class ConfirmBookingLocators extends TestBase{

	@FindBy(how=How.XPATH,using="//tr[7]//td[3]/a")
	protected WebElement logoutImgBtn;
}
