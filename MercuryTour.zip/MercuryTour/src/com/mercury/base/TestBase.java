package com.mercury.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.beust.jcommander.Parameter;
import com.mercury.interfaces.IBookingFlight;
import com.mercury.interfaces.IConfirmBooking;
import com.mercury.interfaces.IHomePage;
import com.mercury.interfaces.ISelectFlight;
import com.mercury.pages.BookFlightPage;
import com.mercury.pages.ConfirmBooking;
import com.mercury.pages.FlightFinderPage;
import com.mercury.pages.HomePage;
import com.mercury.pages.SelectFlightPage;
import com.mercury.util.TestUtil;
import com.relevantcodes.extentreports.model.Log;

public class TestBase {

	protected static WebDriver driver;
	protected Properties prop;
	protected IHomePage homePage;
	protected FlightFinderPage flightFinderPage;
	protected ISelectFlight selectFlightPage;
	protected IBookingFlight bookingFlight;
	protected IConfirmBooking cnfrmbooking;
	protected static Logger log = Logger.getLogger(Log.class.getName());
	protected String configPropertiesPath = "D:\\Selenium_WorkSpace\\MercuryTour\\src\\com\\mercury\\config\\config.properties";
	protected String browserPath = System.getProperty("user.dir") + "\\lib" + "\\chromedriver.exe";
	protected String browserDrive = "webdriver.chrome.driver";
	protected String log4jPropertiesFilePath = System.getProperty("user.dir") + "\\lib" + "\\log4j.properties";
	/*
	 * public static ExtentReports extent; public static ExtentTest logger;
	 */

	@BeforeSuite
	public void initialiazation() {

		try {
			prop = new Properties();
			FileInputStream ip = new FileInputStream(configPropertiesPath);
			prop.load(ip);
			/*
			 * extent = new
			 * ExtentReports(System.getProperty("user.dir")+"\\fileTest.html",
			 * true); extent.loadConfig(new
			 * File(System.getProperty("user.dir")+"\\extent-config.xml"));
			 * logger = extent.startTest("My First Test","Mercury Tours");
			 */
		} catch (FileNotFoundException f) {
			f.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		PropertyConfigurator.configure(log4jPropertiesFilePath);
		String browserName = prop.getProperty("browser");

		if (browserName.equals("chrome")) {
			System.setProperty(browserDrive, browserPath);
			driver = new ChromeDriver();
			log.info("Browser open");
		} else if (browserName.equals("firefox")) {
			/*
			 * System.setProperty("webdriver.gecko.driver",
			 * "D:\\tools\\SeleniumWebDriver\\chromedriver_win32\\chromedriver.exe"
			 * );
			 */
		}

		homePage = new HomePage();
		flightFinderPage = new FlightFinderPage();
		selectFlightPage = new SelectFlightPage();
		bookingFlight = new BookFlightPage();
		cnfrmbooking = new ConfirmBooking();

		driver.manage().window().maximize();
		log.info("Maximizing Window");
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);

		driver.get(prop.getProperty("url"));
		log.info("Launching the Application");
		// logger.log(LogStatus.INFO,"Launching Application");
	}

	@AfterSuite
	public void tearDown() {
		driver.quit();
		log.info("TearDown the Browser");
	}
}
