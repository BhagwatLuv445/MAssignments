package com.mercury.util;

import org.testng.annotations.DataProvider;

public class MercuryDataProvider {
	@DataProvider(name = "mecuryDataProvider")
	public static Object[][] credentials() {

		return new Object[][] { { "Bhagwat", "Prajapati", "Vegetarian", "Visa", "5567899990123456", "11", "2010",
				"Bhagwat", "", "Prajapati", "Bhopal", "M.P.", "462047", "UNITED STATES" } };
	}
}
