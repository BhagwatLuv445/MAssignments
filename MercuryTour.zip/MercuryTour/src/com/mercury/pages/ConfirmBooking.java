package com.mercury.pages;

import org.openqa.selenium.support.PageFactory;

import com.mercury.interfaces.IConfirmBooking;
import com.mercury.locators.ConfirmBookingLocators;

public class ConfirmBooking extends ConfirmBookingLocators implements IConfirmBooking {

	public ConfirmBooking() {

		PageFactory.initElements(driver, this);
	}

	public void clkLogout() {
		logoutImgBtn.click();
		log.info("logout button found and click");
	}
}
