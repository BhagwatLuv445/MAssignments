package com.mercury.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.mercury.interfaces.IBookingFlight;
import com.mercury.locators.BookFlightLocaotars;

public class BookFlightPage extends BookFlightLocaotars implements IBookingFlight{

	// Logger log;

	public BookFlightPage() {
		PageFactory.initElements(driver, this);
	}

	public void serPassengerFirstName(String firstName) {
		passsengerFirstName0.sendKeys(firstName);
	}
	
	public void setPassengerLastName(String lastName){
		passsengerLastName0.sendKeys(lastName);
	}
	
	public void setMeal(String meal){
		new Select(passengerMeal0).selectByVisibleText(meal);;
	}

	public void setCardType(String cardTypeName){
		new Select(cardType).selectByVisibleText(cardTypeName);
	}
	
	public void setCardNumber(String cardNum){
		cardNumber.sendKeys(cardNum);
	}
	
	public void setCardExpMonth(String expMonth){
		new Select(cardExpMonth).selectByVisibleText(expMonth);
	}
	
	public void setExpYear(String expYear){
		new Select(cardExpYear).selectByVisibleText(expYear);
	}
	
	public void setCCfirstName(String ccfirstName){
		ccFirstName.sendKeys(ccfirstName);
	}
	
	public void setCCMidName(String ccmidName){
		ccMidName.sendKeys(ccmidName);
	}
	
	public void setccLastName(String cclastName){
		ccLastName.sendKeys(cclastName);
	}
	
	public void setBillAddress(String billAdd){
		billAddress.sendKeys(billAdd);
	}
	
	public void setBillCity(String billingCity){
		billCity.clear();
		billCity.sendKeys(billingCity);
	}
	
	public void setBillState(String billingState){
		billState.clear();
		billState.sendKeys(billingState);
	}
	
	public void setZip(String zipCode){
		billZipCode.clear();
		billZipCode.sendKeys(zipCode);
	}
	
	public void setBillCountry(String billingCountry){
		new Select(billCountry).selectByVisibleText(billingCountry);
	}
	
	public void clkPurchaseBtn(){
		purchaseBtn.click();		
	}
}
