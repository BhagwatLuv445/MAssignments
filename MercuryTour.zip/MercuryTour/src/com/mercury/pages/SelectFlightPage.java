package com.mercury.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.mercury.interfaces.ISelectFlight;
import com.mercury.locators.SelectFlightLocators;

public class SelectFlightPage extends SelectFlightLocators implements ISelectFlight {

	// Initialization of Page Object
	public SelectFlightPage() {
		PageFactory.initElements(driver, this);
	}

	// Actions
	public void selectDepartFlight(String departFlight) {

		if (departFlight.equalsIgnoreCase("Blue Skies Airlines 360 270 5:03")) {
			log.info("depart flight field element found");
			selectFlight.get(0).click();
			log.info(departFlight+"flight selected");
		} else if (departFlight.equalsIgnoreCase("Blue Skies Airlines 361 271 7:10")) {
			log.info("depart flight field element found");
			selectFlight.get(1).click();
			log.info(departFlight+"flight selected");
		} else if (departFlight.equalsIgnoreCase("Pangea Skies Airlines 362 274 9:17")) {
			log.info("depart flight field element found");
			selectFlight.get(2).click();
			log.info(departFlight+"flight selected");
		} else if (departFlight.equalsIgnoreCase("Unified Airlines 363 281 11:24")) {
			log.info("depart flight field element found");
			selectFlight.get(3).click();
			log.info(departFlight+"flight selected");
		} else {
			log.error("depart flight not found");
		}
	}

	public void selectReturnFlight(String returnFlight) {

		if (returnFlight.equalsIgnoreCase("Blue Skies Airlines 630 270 12:23")) {
			log.info("return flight field element found");
			selectReturnFlight.get(0).click();
			log.info(returnFlight+"flight selected");
		} else if (returnFlight.equalsIgnoreCase("Blue Skies Airlines 631 273 14:30")) {
			log.info("return flight field element found");
			selectReturnFlight.get(1).click();
			log.info(returnFlight+"flight selected");
		} else if (returnFlight.equalsIgnoreCase("Pangea Skies Airlines 632 282 16:37")) {
			log.info("return flight field element found");
			selectReturnFlight.get(2).click();
			log.info(returnFlight+"flight selected");
		} else if (returnFlight.equalsIgnoreCase("Unified Airlines 633 303 18:44")) {
			log.info("return flight field element found");
			selectReturnFlight.get(3).click();
			log.info(returnFlight+"flight selected");
		} else {
			log.error("return flight not found");
		}

	}

	public void clkContinueBtn() {
		continueBtn.click();
		log.info("continue button element found");
		log.info("continue button click");
	}

}
