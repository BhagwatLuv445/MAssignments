package com.mercury.pages;


import org.openqa.selenium.WebDriver;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.mercury.interfaces.IflightFinderPage;
import com.mercury.locators.FlightFinderLocators;

public class FlightFinderPage extends FlightFinderLocators implements IflightFinderPage {

	// initialiazing page object
	public FlightFinderPage() {
		PageFactory.initElements(driver, this);
	}

	// Actions
	public String validateFlightFinderPageTitle() {
		return driver.getTitle();
	}

	public void setTripType(String trip) {

		if (trip.equalsIgnoreCase("Round Trip")) 
		{
			log.info(trip+"Found");
			if (!tripType.get(0).isSelected()) 
			{
				tripType.get(0).click();
				log.info("Round Trip Radio Button selected");
			}
		} 
		else if (trip.equalsIgnoreCase("One Way")) 
		{
			log.info(trip+"found");
			if (!tripType.get(1).isSelected()) {
				tripType.get(1).click();
				log.info("One Way trip Radio Button Selected");
			}
		} else {
			log.error("trip not found");
		}		
	}

	public void setPassenger(String passenger) {
		Select selectPassenger = new Select(passengerCount);
		log.info("passenger Number element found");
		selectPassenger.selectByVisibleText(passenger);
		log.info("passenger Number ");
	}

	public void setDepartingFrom(String departFrom) {
		Select selectDepartFrom = new Select(departingFrom);
		log.info("Departing station element found");
		selectDepartFrom.selectByVisibleText(departFrom);
		log.info("Departing station has entered");
	}

	public void setDepartMonth(String departMonth) {
		Select selectDepartMonth = new Select(departingMonth);
		log.info("Departing month element found");
		selectDepartMonth.selectByVisibleText(departMonth);
		log.info("depart Month entered using selected by visibletext");
	}

	public void setDepartDay(String departDay) {
		Select selectDepartDay = new Select(departingDay);
		log.info("departing day field element has found");
		selectDepartDay.selectByVisibleText(departDay);
		log.info("departing day entered");
	}

	public void setArrivingPort(String arrivingPlace) {
		Select selectArrivingPort = new Select(arrivingPort);
		log.info("arriving place field element found");
		selectArrivingPort.selectByVisibleText(arrivingPlace);
		log.info("Arriving place enetered");
	}

	public void setArrivingMonth(String arriveMonth) {
		Select selectArrivingMonth = new Select(arrivingMonth);
		log.info("arriveMonth field element found");
		selectArrivingMonth.selectByVisibleText(arriveMonth);
		log.info("arrive month entered");
	}

	public void setArrivingDay(String arriveDay) {
		Select selectArrivingDay = new Select(arrivingDay);
		log.info("arrive day field element found");
		selectArrivingDay.selectByVisibleText(arriveDay);
		log.info("arrive day entered");
	}

	public void setServiceClass(String servClass) {
		if (servClass.equalsIgnoreCase("Economy Class")) {
			log.info(servClass+"servClass found");
			if (!serviceClass.get(0).isSelected()) {
				log.info("service class field element found");
				serviceClass.get(0).click();
				log.info("service class selected");
			}
		} else if (servClass.equalsIgnoreCase("Business Class")) {
			log.info(servClass+"servClass found");
			if (!serviceClass.get(1).isSelected()) {
				serviceClass.get(1).click();
			}
		} else if (servClass.equalsIgnoreCase("First Class")) {
			log.info(servClass+"servClass found");
			if (!serviceClass.get(2).isSelected()) {				
				log.info("service class field element found");
				serviceClass.get(2).click();
				log.info("service class selected");				
			} else {
				log.error("service class not found");
			}
		}
	}

	public void setAirLine(String airline) {
		Select selectAirLine = new Select(airLine);		
		selectAirLine.selectByVisibleText(airline);
		log.info("airline field element found");
		log.info("airline name entered");
	}

	public void clkContinue() {
		continueBtn.click();	
		log.info("continue button found");
		log.info("clicked on continue button");
	}

}
