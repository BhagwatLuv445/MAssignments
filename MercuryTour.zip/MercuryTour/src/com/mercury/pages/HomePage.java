package com.mercury.pages;

import org.openqa.selenium.support.PageFactory;

import com.mercury.interfaces.IHomePage;
import com.mercury.locators.HomePageLocators;

public class HomePage extends HomePageLocators implements IHomePage {

	// Page Factory - OR:

	// Initializing the page object
	public HomePage() {
		PageFactory.initElements(driver, this);
	}

	// Actions:
	public String validateHomePageTitle() {
		return driver.getTitle();
	}

	public void logIn(String un, String pwd) {
		userNameField.sendKeys(un);
		log.info("User Name Field found");
		log.info("User Name entered in the user name field");
		passWordField.sendKeys(pwd);
		log.info("Password Field found");
		log.info("Password entered in the Password field");
		loginBtn.click();
		log.info("login button clicked");
	}

}
